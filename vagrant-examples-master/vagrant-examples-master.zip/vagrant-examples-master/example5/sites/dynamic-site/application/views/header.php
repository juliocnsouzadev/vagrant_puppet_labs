<!DOCTYPE html>
<html>
<head>
    <title>Vagrant Wish List</title>
    <link rel="stylesheet" href="/assets/reset.css"/>
    <link rel="stylesheet" href="/assets/dynamic.css"/>
</head>
<body>
<div id="container">
