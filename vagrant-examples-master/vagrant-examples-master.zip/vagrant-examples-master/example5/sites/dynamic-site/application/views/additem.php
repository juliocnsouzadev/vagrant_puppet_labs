<h1>Add New Item</h1>
<form method="post" action="/add.php">
    <p>
        <label for="name">Name</label>
        <input type="text" id="name" name="name"/>
    </p>
    <p>
        <label for="desc">Description</label>
        <input type="text" id="desc" name="desc"/>
    </p>
    <p>
        <input type="submit" id="add" name="add" value="Add"/>
    </p>
</form>
